export function getGradeLabel(grade){
  return grade === '0' ? 'K' : grade;
}