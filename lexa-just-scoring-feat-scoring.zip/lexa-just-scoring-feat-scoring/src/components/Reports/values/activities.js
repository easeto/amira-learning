// react-i18next me
// bs - tie in real types
const activities = {
  INS: {
    label: 'Instruction',
    value: 'INS',
    description: 'Instruction'
  },
  PRC: {
    label: 'Practice',
    value: 'PRC',
    description: 'Practice'
  },
}

export default activities