// react-i18next me
// HIERARCHICAL LIST:
// ORDER IS OF PARAMOUNT IMPORTANCE
const levels = [
  {
    label: 'Districts',
    value: 'district',
  },
  {
    label: 'Schools',
    value: 'school',
  },
  {
    label: 'Classrooms',
    value: 'classroom',
  },
  {
    label: 'Students',
    value: 'student',
  },
]

export default levels