// react-i18next me
// RENAME ME
const levels = {
  district: {label: 'Districts', value: 'district'},
  school: {label: 'Schools', value: 'school'},
  classroom: {label: 'Classrooms', value: 'classroom'},
  student: {label: 'Students', value: 'student'},
}

export default levels