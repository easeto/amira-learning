import ReportingPortal from './index';



module.exports = [{
  path: '/teacher/reports',
  component: ReportingPortal,
  },
];
