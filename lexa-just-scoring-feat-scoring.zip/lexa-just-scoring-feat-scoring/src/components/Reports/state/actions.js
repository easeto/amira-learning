import types from './constants'

export default {
  [types.REPORT_CLEAR]: () => ({
    type: types.REPORT_CLEAR,
  }),
}