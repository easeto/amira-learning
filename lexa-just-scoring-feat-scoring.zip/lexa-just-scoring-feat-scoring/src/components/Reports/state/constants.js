export default {
  REPORT_CLEAR: 'REPORT_CLEAR',
}