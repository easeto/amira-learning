import React from 'react';

export default class Resources extends React.Component {
  render() {
    return (
      <div style={{textAlign: 'center', position: 'relative', bottom: '300px'}}>Resource not found</div>
    );
  }
}
